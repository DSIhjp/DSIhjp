package com.gaore.sdk;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.gaore.sdk.bean.GrPayParams;
import com.gaore.sdk.bean.GrTokenBean;
import com.gaore.sdk.bean.GrUserExtraData;
import com.gaore.sdk.common.GrCode;
import com.gaore.sdk.common.GrSDKCallBack;
import com.gaore.sdk.utils.LogUtil;
import com.gaore.testgame.demo.R;

public class MainActivity extends Activity {
	private ImageView mIvPay;
	private TextView mTvUserName;

	private Button mBtnLogin;
	private Button mBtnCreateRole;
	private Button mBtnLogout;
	private Button mBtnCustomer;
	private Button mBtnAccount;

	private boolean isLogin = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gr_home);
		LogUtil.isDebug(false);
		mBtnLogin = (Button) findViewById(R.id.btn_login);
		mIvPay = (ImageView) (findViewById(R.id.tv_pay));
		mTvUserName = (TextView) (findViewById(R.id.tv_username));
		mBtnCreateRole = (Button) findViewById(R.id.btn_createRole);
		mBtnCustomer = (Button) findViewById(R.id.btn_customer);
		mBtnAccount = (Button) findViewById(R.id.btn_account);
		mBtnLogout = (Button) findViewById(R.id.btn_logout);
		// 初始化
		GrAPI.getInstance().grInitSDK(this, new GrSDKCallBack() {
			@Override
			public void onInitResult(int resultCode) {
				if (resultCode == GrCode.GR_COM_PLATFORM_SUCCESS) {
					LogUtil.i("gaore", "init success");
				} else {
					LogUtil.i("gaore", "init fail");
				}
			}

			@Override
			public void onLoginResult(GrTokenBean authResult) {
				LogUtil.i("gaore", "get token success,  tokenInfo : " + authResult);
				if (authResult.isSuc()) {
					mTvUserName.setText(authResult.getUsername());
					isLogin = true;
					LogUtil.i("gaore", "channelID:" + authResult.getChannelID());
					LogUtil.i("gaore", "Token:" + authResult.getToken());
					LogUtil.i("gaore", "userid : " + authResult.getUserID());
				} else {
					LogUtil.i("gaore", "get Token fail");
				}
			}

			@Override
			public void onLogoutResult(int resultCode) {
				LogUtil.i("gaore", "logout success");
				if (resultCode == GrCode.LOGOUT_ACCOUNT_SUCCESS) {
					mTvUserName.setText("未登录");
					return;
				}

			}
			
			@Override
			public void onPayResult(int result) {
				if (result == GrCode.PAY_GAORE_SUCCESS) {
					Toast.makeText(MainActivity.this, "支付成功", Toast.LENGTH_SHORT).show();
				} else if (result == GrCode.PAY_GAORE_FAILED) {
					Toast.makeText(MainActivity.this, "支付失败", Toast.LENGTH_SHORT).show();
				}
			}

			@Override
			public void onExit() {
				MainActivity.this.finish();
				System.exit(0);
			}
			@Override
			public void onLoginCancel() {
				Toast.makeText(MainActivity.this, "取消登录成功", Toast.LENGTH_SHORT).show();
			}
			@Override
			public void onPermissionsResult(int result) {
				if (result == GrCode.GR_REQUEST_PERMISSIONS_GRANTED) {//授权成功
					Toast.makeText(MainActivity.this, "授权成功", Toast.LENGTH_SHORT).show();
				}else if (result == GrCode.GR_REQUEST_PERMISSIONS_GRANTEDED) {//已授权
					Toast.makeText(MainActivity.this, "已授权", Toast.LENGTH_SHORT).show();
				}
			}
		});

		GrAPI.getInstance().grOnCreate(savedInstanceState);
		// 登录
		mBtnLogin.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				GrAPI.getInstance().grLogin(MainActivity.this);
			}
		});

		// 支付
		mIvPay.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				pay();
			}
		});

		// 事件上报，当前仅举例一种时机
		mBtnCreateRole.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				submitExtendData();
			}
		});

		// 客服窗口
		mBtnCustomer.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (isLogin)
					GrAPI.getInstance().grShowCustomerDialog(MainActivity.this);
			}
		});
		// 用户窗口
		mBtnAccount.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (isLogin)
					GrAPI.getInstance().grShowAccountDialog(MainActivity.this);
			}
		});
		// 注销
		mBtnLogout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if (isLogin)
					GrAPI.getInstance().grLogout(MainActivity.this);
			}
		});
		DisplayMetrics metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		int screenHeight = metrics.heightPixels;//屏幕高度像素
		int screenWidth = metrics.widthPixels;//屏幕宽度像素
		//density = densityDpi / 160
		float density = metrics.density;// "屏幕密度"（0.75 / 1.0 / 1.5）
		int densityDpi = metrics.densityDpi;// 屏幕密度dpi（120 / 160 / 240）每一英寸的屏幕所包含的像素数.值越高的设备，其屏幕显示画面的效果也就越精细
		// 屏幕宽度算法:屏幕宽度（像素）/"屏幕密度"   px = dp * (dpi / 160)
		int height = (int) (screenHeight / density);//屏幕高度dp
		int width = (int) (screenWidth / density);//屏幕宽度dp
		Log.e("gaore","width dp is " + width);
		Log.e("gaore","height dp is " + height);
	}

	// 退出
	@Override
	public void onBackPressed() {
		super.onBackPressed();
		GrAPI.getInstance().grExit(this);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			GrAPI.getInstance().grExit(this);

		}
		return false;
	}

	@SuppressLint("NewApi")
	private void pay() {
		GrPayParams params = new GrPayParams();
		params.setBuyNum(1); // 写默认1
		params.setCoinNum(100); // 写默认100
		params.setExtension(System.currentTimeMillis() + "");
		params.setPrice(1); // 单位是元
		params.setProductId("1");
		params.setProductName("元宝");
		params.setProductDesc("购买100元宝");
		params.setRoleId("1");
		params.setRoleLevel(1);
		params.setRoleName("测试角色名");
		params.setServerId("1");
		params.setServerName("测试");
		params.setVip("vip1");
		GrAPI.getInstance().grPay(MainActivity.this, params);
	}

	private void submitExtendData() {
		GrUserExtraData extraData = new GrUserExtraData();
		extraData.setDataType(2); // 调用时机，具体见文档
		extraData.setServerID(1 + ""); // 未获取到服务器时传0
		extraData.setServerName("服务器名称"); // 未获取到服务器名称时传null
		extraData.setRoleName("角色名名称"); // 角色未获取或未创建时传null
		extraData.setRoleLevel("1"); // 当前角色等级,未获取到角色等级时传null
		extraData.setRoleID("123456789"); // 当前角色id,未获取角色id时传null
		extraData.setOrderId("7890123456");// 订单id，未获取时传null
		extraData.setMoney(0);// 充值金额，单位分，未获取时传0
		extraData.setMoneyNum(0 + ""); // 玩家身上元宝数量，拿不到或者未获取时传0
		extraData.setRoleCreateTime(System.currentTimeMillis() / 1000);// 角色创建时间，未获取或未创建角色时传0
		extraData.setGuildId("GH10001");// 公会id，无公会或未获取时传null
		extraData.setGuildName("公会名称");// 公会名称，无公会或未获取时传null
		extraData.setGuildLevel(100 + "");// 公会等级，无公会或未获取时传0
		extraData.setGuildLeader("公会会长名");// 公会会长名称，无公会或未获取时传null
		extraData.setPower(123123); // 角色战斗力, 不能为空，必须是数字，不能为null,若无,传0
		extraData.setProfessionid(123);// 职业ID，不能为空，必须为数字，若无，传入 0
		extraData.setProfession("职业名称");// 职业名称，不能为空，不能为 null，若无，传入 “无”
		extraData.setGender("性别");// 角色性别，不能为空，不能为 null，可传入参数“ 男、女、无”
		extraData.setProfessionroleid(123);// 职业称号ID，不能为空，不能为 null，若无，传入 0
		extraData.setProfessionrolename("职业称号");// 职业称号，不能为空，不能为 null，若无，传入“ 无”
		extraData.setVip(9);// 玩家VIP等级，不能为空，必须为数字,若无，传入 0
		extraData.setGuildroleid(123);// 帮派称号 ID，帮派会长/帮主必传 1，其他可自定义，不能为空，不能为
										// null，若无，传入 0
		extraData.setGuildrolename("帮派称号名称");// 帮派称号名称，不能为空，不能为 null，若无，传入“无”
		Toast.makeText(MainActivity.this, extraData + "", Toast.LENGTH_SHORT).show();
		GrAPI.getInstance().grSubmitExtendData(MainActivity.this, extraData);
	}

	@Override
	protected void onStart() {
		super.onStart();
		GrAPI.getInstance().grOnStart();
	}

	@Override
	protected void onPause() {
		super.onPause();
		GrAPI.getInstance().grOnPause();
	}

	@Override
	protected void onResume() {
		super.onResume();
		GrAPI.getInstance().grOnResume();
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		GrAPI.getInstance().grOnNewIntent(intent);
	}

	@Override
	protected void onStop() {
		super.onStop();
		GrAPI.getInstance().grOnStop();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		GrAPI.getInstance().grOnDestroy();
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		GrAPI.getInstance().grOnRestart();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		GrAPI.getInstance().grOnConfigurationChanged(newConfig);
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		GrAPI.getInstance().grOnSaveInstanceState(outState);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		GrAPI.getInstance().grOnActivityResult(requestCode, resultCode, data, this);
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		GrAPI.getInstance().grOnRequestPermissionsResult(MainActivity.this, requestCode, permissions, grantResults);
	}
}
