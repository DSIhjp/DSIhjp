package com.gaore.sdk;

import android.app.Application;
import android.content.Context;
import android.content.res.Configuration;

public class GRApplication extends Application {
	private static Application instance;

	public static Application getApplication() {
		return instance;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		GrAPI.getInstance().grOnAppCreate(this);
		instance = this;
	}

	@Override
	public void attachBaseContext(Context base) {
		super.attachBaseContext(base);
		GrAPI.getInstance().grOnAppAttachBaseContext(this, base);
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		GrAPI.getInstance().grOnAppConfigurationChanged(this, newConfig);
	}
}
